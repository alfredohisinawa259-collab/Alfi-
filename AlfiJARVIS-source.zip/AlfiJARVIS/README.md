# Alfi JARVIS — starter project

Este é um primeiro projeto-fonte Android para continuar o desenvolvimento do Alfi. O ZIP original enviado continha apenas `app-debug.apk`, não os fontes Kotlin/Gradle originais; por isso este projeto é um início reconstruído e não uma edição direta do APK.

## Já incluído
- Interface simples em português.
- Reconhecimento de voz acionado pelo utilizador (uma sessão de cada vez).
- Resposta falada por Text-to-Speech.
- Comandos para abrir definições, abrir o marcador, ligar/desligar a lanterna e abrir SMS para um número.
- Pedidos de permissão de microfone e câmara no momento de utilização.

## Limites desta versão
- Ainda não inclui o modelo Vosk offline, uma API de IA, memória de conversação ou escuta contínua.
- O reconhecimento do Android pode exigir internet conforme o motor de voz instalado.
- Chamadas e SMS abrem o marcador/aplicação de mensagens; o utilizador confirma a ação.
- Não inclui ainda serviço persistente de microfone nem AccessibilityService. Estes devem ser adicionados numa fase separada, com consentimento explícito e respeitando as restrições da versão Android.

## Abrir
1. Descompacta `AlfiJARVIS-source.zip`.
2. Abre a pasta `AlfiJARVIS` no Android Studio.
3. Deixa o Gradle sincronizar e instala num telefone Android para testar.
4. Se o Android Studio pedir, instala Android SDK 35 e usa JDK 17.

## Próximas fases
1. Integrar Vosk com o modelo de português compatível.
2. Criar `CommandProcessor` e separar os comandos da interface.
3. Adicionar IA online através de um backend seguro (não colocar chaves secretas dentro do APK).
4. Implementar serviço em primeiro plano com notificação visível e iniciar escuta apenas nos estados permitidos pelo Android.
5. Adicionar automações de acessibilidade opcionais, ativadas manualmente pelo utilizador.

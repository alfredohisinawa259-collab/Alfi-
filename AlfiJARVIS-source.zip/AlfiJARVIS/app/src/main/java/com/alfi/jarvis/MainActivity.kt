package com.alfi.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var response: TextView
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var torchOn = false
    private val requestAudio = 41
    private val requestCamera = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "ALFI  •  JARVIS"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Pronto. Carrega no botão e fala comigo."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 12)
        }
        response = TextView(this).apply {
            text = "Comandos iniciais: abrir definições, abrir telefone, ligar lanterna, desligar lanterna, ligar para um número, enviar SMS."
            textSize = 16f
            setPadding(0, 12, 0, 20)
        }
        val listen = Button(this).apply {
            text = "🎙 FALAR COM O ALFI"
            setOnClickListener { checkAudioAndListen() }
        }
        val settings = Button(this).apply {
            text = "Abrir definições"
            setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        val dial = Button(this).apply {
            text = "Abrir telefone"
            setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL)) }
        }
        root.addView(title, match())
        root.addView(status, match())
        root.addView(listen, match())
        root.addView(response, match())
        root.addView(settings, match())
        root.addView(dial, match())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("pt", "PT")
    }

    private fun checkAudioAndListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        } else listenOnce()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listenOnce()
        if (requestCode == requestCamera && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) setTorch(!torchOn)
    }

    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("O serviço de reconhecimento de voz não está disponível neste telefone.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou a ouvir…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "A interpretar…" }
                override fun onError(error: Int) { status.text = "Não consegui reconhecer. Tenta novamente." }
                override fun onResults(results: Bundle?) {
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    response.text = "Tu: $phrase"
                    handleCommand(phrase.lowercase(Locale.ROOT))
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Diz o teu comando para o Alfi")
            }
            recognizer.startListening(intent)
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("definições") || command.contains("configurações") -> {
                say("A abrir as definições."); startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            command.contains("abre o telefone") || command == "abrir telefone" || command.contains("abre chamadas") -> {
                say("A abrir o telefone."); startActivity(Intent(Intent.ACTION_DIAL))
            }
            command.contains("liga a lanterna") || command.contains("acende a lanterna") -> {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), requestCamera)
                } else setTorch(true)
            }
            command.contains("desliga a lanterna") || command.contains("apaga a lanterna") -> setTorch(false)
            command.startsWith("ligar para ") || command.startsWith("liga para ") -> {
                val number = command.substringAfter("para ").filter { it.isDigit() || it == '+' }
                if (number.isNotBlank()) {
                    say("Vou abrir o marcador para confirmares a chamada.")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                } else say("Não consegui identificar o número.")
            }
            command.startsWith("enviar sms para ") -> {
                val number = command.substringAfter("para ").filter { it.isDigit() || it == '+' }
                if (number.isNotBlank()) {
                    say("Vou abrir as mensagens. Confirma o destinatário e o texto antes de enviar.")
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")))
                } else say("Diz: enviar SMS para, seguido do número.")
            }
            command.contains("ajuda") || command.contains("que podes fazer") -> say("Posso abrir definições, abrir o telefone e controlar a lanterna. Mais funções serão adicionadas.")
            else -> say("Ainda não tenho esse comando. Diz ajuda para ouvires os comandos disponíveis.")
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { say("Este telefone não disponibiliza uma lanterna compatível."); return }
            manager.setTorchMode(cameraId, on)
            torchOn = on
            say(if (on) "Lanterna ligada." else "Lanterna desligada.")
        } catch (e: Exception) {
            say("Não consegui controlar a lanterna. Verifica a permissão e tenta novamente.")
        }
    }

    private fun say(message: String) {
        status.text = message
        response.text = message
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "alfi-response")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
